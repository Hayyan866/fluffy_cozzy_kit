// cart.js

// Function to update cart count
function updateCartCount() {
    try {
        const cart = getCart();
        const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
        const cartCountElement = document.getElementById('cartCount');
        if (cartCountElement) {
            cartCountElement.textContent = totalItems;
        }
    } catch (error) {
        console.error('Error updating cart count:', error);
    }
}

// Function to render cart items in the side panel
function renderCart() {
    try {
        const cartItemsContainer = document.getElementById('cartItems');
        const cartTotalElement = document.getElementById('cartTotal');
        const cart = getCart();

        if (!cartItemsContainer || !cartTotalElement) return;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
            cartTotalElement.innerHTML = '';
            return;
        }

        cartItemsContainer.innerHTML = '';
        let totalPrice = 0;

        cart.forEach(item => {
            const itemTotal = item.price * (item.quantity || 1);
            totalPrice += itemTotal;

            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <img src="${item.image || 'placeholder.png'}" alt="${item.name}">
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>Price: ${item.price} Rs</p>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="updateItemQuantity('${item.id}', ${item.quantity - 1})">–</button>
                        <span>Qty: ${item.quantity || 1}</span>
                        <button class="quantity-btn" onclick="updateItemQuantity('${item.id}', ${item.quantity + 1})">+</button>
                    </div>
                    <p>Total: ${itemTotal} Rs</p>
                </div>
                <button class="remove-btn" onclick="removeItem('${item.id}')">Remove</button>
            `;
            cartItemsContainer.appendChild(cartItem);
        });

        cartTotalElement.innerHTML = `Subtotal: ${totalPrice} Rs`;
    } catch (error) {
        console.error('Error rendering cart:', error);
    }
}

// Function to toggle cart panel
function toggleCartPanel(open = true) {
    const cartPanel = document.getElementById('cartPanel');
    const overlay = document.getElementById('cartOverlay');
    if (open) {
        cartPanel.classList.add('open');
        overlay.classList.add('active');
        renderCart();
    } else {
        cartPanel.classList.remove('open');
        overlay.classList.remove('active');
    }
}

// Function to handle checkout
function checkout() {
    window.location.href = 'checkout.html';
}

// Function to add item to cart
function addAccessoryToCart(itemId) {
    try {
        const item = accessoriesData.find(accessory => accessory.id === itemId);
        if (!item) {
            console.error(`Accessory with ID ${itemId} not found`);
            return;
        }
        addToCart(item); // Use addToCart from cart.js
    } catch (error) {
        console.error('Error adding item to cart:', error);
    }
}

// Retrieve cart from localStorage
function getCart() {
    try {
        const cart = localStorage.getItem('cart');
        return cart ? JSON.parse(cart) : [];
    } catch (error) {
        console.error('Error parsing cart from localStorage:', error);
        throw error;
    }
}

// Save cart to localStorage
function saveCart(cart) {
    try {
        localStorage.setItem('cart', JSON.stringify(cart));
        document.dispatchEvent(new Event('cartUpdated'));
    } catch (error) {
        console.error('Error saving cart to localStorage:', error);
        throw error;
    }
}

// Update item quantity
function updateItemQuantity(id, quantity) {
    let cart = getCart();
    const itemIndex = cart.findIndex(item => item.id === id);
    if (itemIndex !== -1) {
        if (quantity <= 0) {
            removeItem(id);
        } else {
            cart[itemIndex].quantity = quantity;
            saveCart(cart);
        }
    } else {
        console.error('Item not found in cart');
    }
}

// Remove item from cart
function removeItem(id) {
    let cart = getCart();
    cart = cart.filter(item => item.id !== id);
    saveCart(cart);
}

// Add item to cart
function addToCart(item) {
    if (!item || !item.id || !item.name || !item.price) {
        throw new Error('Item must have id, name, and price properties');
    }
    let cart = getCart();
    const itemIndex = cart.findIndex(cartItem => cartItem.id === item.id);
    if (itemIndex !== -1) {
        cart[itemIndex].quantity = (cart[itemIndex].quantity || 1) + 1;
    } else {
        cart.push({ ...item, quantity: 1 });
    }
    saveCart(cart);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    const openCartBtn = document.getElementById('openCart');
    const closeCartBtn = document.getElementById('closeCart');
    const overlay = document.getElementById('cartOverlay');

    if (openCartBtn) openCartBtn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleCartPanel(true);
    });

    if (closeCartBtn) closeCartBtn.addEventListener('click', () => toggleCartPanel(false));
    if (overlay) overlay.addEventListener('click', () => toggleCartPanel(false));

    updateCartCount();
});

// Listen for cart updates
document.addEventListener('cartUpdated', () => {
    updateCartCount();
    renderCart();
});



