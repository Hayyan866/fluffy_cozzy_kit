Group members: Hayaan Abubakar (22p9340), 
Muhammad Mairaj (22p9327), 
Fawad Ahmed(21p8317)
Project Name: Fluffy cozy kit

Project breakdown: Hayaan Abubakar: Adult cats, kittens, Cat food, 
Muhammad Mairaj: Accessories, Account, Admin 
Fawad Ahmed: Product details, Homepage, Checkout.

We have worked together and divided accordingly on only html for now.
